import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  Pressable,
} from "react-native";
import React, { useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import Ionicons from "react-native-vector-icons/Ionicons"; // ✅ Import Icon
import Checkbox from "expo-checkbox"; // ✅ Import Checkbox
import COLORS from "../constants/colors";

const Signup = ({ navigation }) => {
  const [isPasswordShow, setIsPasswordShow] = useState(false);
  const [isChecked, setIsChecked] = useState(false);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.white }}>
      <View style={{ flex: 1, marginHorizontal: 22 }}>
        <View style={{ marginVertical: 22 }}>
          <Text
            style={{
              fontSize: 22,
              fontWeight: "bold",
              marginVertical: 12,
              color: COLORS.black,
            }}
          >
            Create Account
          </Text>
          <Text style={{ fontSize: 16, color: COLORS.black }}>
            Connect with your friends today!
          </Text>
        </View>

        {/* Email Input */}
        <View style={{ marginBottom: 12 }}>
          <Text style={{ fontSize: 16, fontWeight: "600", marginVertical: 8 }}>
            Email address
          </Text>
          <View
            style={{
              width: "100%",
              height: 48,
              borderColor: COLORS.primary,
              borderWidth: 1,
              borderRadius: 8,
              justifyContent: "center",
              paddingLeft: 12,
            }}
          >
            <TextInput
              placeholder="Enter your email address"
              placeholderTextColor={COLORS.grey}
              keyboardType="email-address"
              style={{ width: "100%" }}
            />
          </View>
        </View>

        {/* Mobile Number Input */}
        <View style={{ marginBottom: 12 }}>
          <Text style={{ fontSize: 16, fontWeight: "600", marginVertical: 8 }}>
            Mobile Number
          </Text>
          <View
            style={{
              width: "100%",
              height: 48,
              borderColor: COLORS.primary,
              borderWidth: 1,
              borderRadius: 8,
              flexDirection: "row",
              alignItems: "center",
              paddingLeft: 12,
            }}
          >
            <TextInput
              placeholder="+84"
              placeholderTextColor={COLORS.black}
              keyboardType="numeric"
              style={{
                width: "15%",
                borderRightWidth: 1,
                borderRightColor: COLORS.grey,
                textAlign: "center",
              }}
            />
            <TextInput
              placeholder="Enter your phone number"
              placeholderTextColor={COLORS.grey}
              keyboardType="numeric"
              style={{ width: "80%", paddingLeft: 10 }}
            />
          </View>
        </View>

        {/* Password Input */}
        <View style={{ marginBottom: 12 }}>
          <Text style={{ fontSize: 16, fontWeight: "600", marginVertical: 8 }}>
            Password
          </Text>
          <View
            style={{
              width: "100%",
              height: 48,
              borderColor: COLORS.primary,
              borderWidth: 1,
              borderRadius: 8,
              flexDirection: "row",
              alignItems: "center",
              paddingLeft: 12,
            }}
          >
            <TextInput
              placeholder="Enter your password"
              placeholderTextColor={COLORS.grey}
              secureTextEntry={!isPasswordShow} // ✅ Hiển thị hoặc ẩn mật khẩu đúng cách
              style={{ flex: 1 }}
            />
            <TouchableOpacity
              onPress={() => setIsPasswordShow(!isPasswordShow)}
              style={{ padding: 10 }}
            >
              <Ionicons
                name={isPasswordShow ? "eye-off" : "eye"}
                size={24}
                color={COLORS.black}
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* Checkbox */}
        <View style={{ flexDirection: "row", alignItems: "center", marginVertical: 6 }}>
          <Checkbox
            style={{ marginRight: 8 }}
            value={isChecked}
            onValueChange={setIsChecked}
            color={isChecked ? COLORS.info : undefined}
          />
          <Text> I agree to the terms and conditions</Text>
        </View>

        {/* Signup Button */}
        <TouchableOpacity
          onPress={() => console.log("Sign Up Pressed")}
          style={{
            backgroundColor: COLORS.info,
            padding: 14,
            borderRadius: 8,
            borderColor: COLORS.greenInfo,
            borderWidth: 1,
            alignItems: "center",
            marginTop: 18,
          }}
        >
          <Text style={{ color: COLORS.white, fontWeight: "bold", fontSize: 16 }}>
            Sign Up
          </Text>
        </TouchableOpacity>

        {/* OR Divider */}
        <View style={{ flexDirection: "row", alignItems: "center", marginVertical: 20 }}>
          <View style={{ flex: 1, height: 1, backgroundColor: COLORS.grey }} />
          <Text style={{ fontSize: 14, marginHorizontal: 10 }}>Or Sign up with</Text>
          <View style={{ flex: 1, height: 1, backgroundColor: COLORS.grey }} />
        </View>

        {/* Social Login Buttons */}
        <View style={{ flexDirection: "row", justifyContent: "center" }}>
          <TouchableOpacity
            style={{
              flex: 1,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              height: 52,
              borderWidth: 1,
              borderColor: COLORS.primary,
              borderRadius: 10,
              marginRight: 4,
            }}
          >
            <Image
              source={require("../assets/facebook.png")}
              style={{ height: 36, width: 36, marginRight: 8 }}
              resizeMode="contain"
            />
            <Text> Facebook</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flex: 1,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              height: 52,
              borderWidth: 1,
              borderColor: COLORS.primary,
              borderRadius: 10,
            }}
          >
            <Image
              source={require("../assets/google.png")}
              style={{ height: 36, width: 36, marginRight: 8 }}
              resizeMode="contain"
            />
            <Text> Google</Text>
          </TouchableOpacity>
        </View>

        {/* Already have an account */}
        <View style={{ flexDirection: "row", justifyContent: "center", marginVertical: 22 }}>
          <Text style={{ fontSize: 16, color: COLORS.black }}>Already have an account?</Text>
          <Pressable onPress={() => navigation.navigate("Login")}>
            <Text style={{ fontSize: 16, color: COLORS.info, fontWeight: "bold", marginLeft: 6 }}>
              Login
            </Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default Signup;
