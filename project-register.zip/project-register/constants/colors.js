const COLORS = {
  white: "#FFFFFF",
  black: "#222222",
  primary:'#007260',
  secondary: "#39B68D",
  grey: "#cccccc",
  greenInfo: '#05fad1',
  info: '#2bbef9'
}
export default COLORS